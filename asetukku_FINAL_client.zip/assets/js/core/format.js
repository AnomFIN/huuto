export const money = (n) => new Intl.NumberFormat("fi-FI",{style:"currency",currency:"EUR"}).format(Number(n||0));
export const clamp = (n,min,max)=>Math.max(min,Math.min(max,n));
export const escapeHtml = (s)=>String(s??"")
  .replaceAll("&","&amp;").replaceAll("<","&lt;")
  .replaceAll(">","&gt;").replaceAll('"',"&quot;");

export function qs(name, url=location.href){
  const u = new URL(url);
  return u.searchParams.get(name);
}
export function setQS(name,value){
  const u = new URL(location.href);
  if(value===null||value===undefined||value==="") u.searchParams.delete(name);
  else u.searchParams.set(name,value);
  history.replaceState({}, "", u.toString());
}
