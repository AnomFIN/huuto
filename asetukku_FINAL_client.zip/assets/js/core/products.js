import { storage } from "./storage.js";

let cache = null;

export async function loadProducts(){
  if(cache) return cache;
  const res = await fetch("data/products.json", {cache:"no-store"});
  cache = await res.json();
  return cache;
}

export function getProductById(products, id){
  return products.find(p => String(p.id) === String(id));
}

export function searchProducts(products, q){
  const s = String(q||"").trim().toLowerCase();
  if(!s) return [];
  return products
    .filter(p => (`${p.name} ${p.brand||""} ${p.category||""} ${p.subcategory||""}`.toLowerCase().includes(s)))
    .slice(0, 12);
}

export function filterProducts(products, opts){
  let out = products.slice();
  if(opts.category) out = out.filter(p => p.category === opts.category);
  if(opts.subcategory) out = out.filter(p => p.subcategory === opts.subcategory);
  if(opts.brands?.length) out = out.filter(p => opts.brands.includes(p.brand));
  if(opts.badges?.length) out = out.filter(p => opts.badges.includes(p.badge));
  if(opts.q){
    const s = String(opts.q).toLowerCase();
    out = out.filter(p => (`${p.name} ${p.brand||""} ${p.category||""} ${p.subcategory||""}`.toLowerCase().includes(s)));
  }
  if(Number.isFinite(opts.minPrice)) out = out.filter(p => p.price >= opts.minPrice);
  if(Number.isFinite(opts.maxPrice)) out = out.filter(p => p.price <= opts.maxPrice);

  const sort = opts.sort || "popular";
  if(sort==="price_asc") out.sort((a,b)=>a.price-b.price);
  if(sort==="price_desc") out.sort((a,b)=>b.price-a.price);
  if(sort==="new") out.sort((a,b)=>String(b.created||"").localeCompare(String(a.created||"")));
  if(sort==="rating") out.sort((a,b)=>(b.rating||0)-(a.rating||0));
  return out;
}

export function brandsFor(products, category){
  const s = new Set();
  products.filter(p=>p.category===category).forEach(p=>s.add(p.brand));
  return Array.from(s).sort((a,b)=>a.localeCompare(b,"fi"));
}
