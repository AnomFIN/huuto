export const storage = {
  get(key, fallback=null){
    try{
      const v = localStorage.getItem(key);
      return v===null ? fallback : JSON.parse(v);
    }catch(e){ return fallback; }
  },
  set(key, value){
    localStorage.setItem(key, JSON.stringify(value));
  },
  del(key){ localStorage.removeItem(key); }
};
