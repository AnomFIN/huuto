import { storage } from "./storage.js";
import { clamp } from "./format.js";

const KEY = "asetukku_cart_v2";

export function getCart(){
  return storage.get(KEY, {});
}
export function setCart(cart){
  storage.set(KEY, cart || {});
}
export function cartCount(cart=getCart()){
  return Object.values(cart).reduce((a,b)=>a+Number(b||0), 0);
}
export function addToCart(id, qty=1){
  const cart = getCart();
  const k = String(id);
  cart[k] = clamp((cart[k]||0)+Number(qty||1), 0, 999);
  if(cart[k] <= 0) delete cart[k];
  setCart(cart);
  return cart;
}
export function setQty(id, qty){
  const cart = getCart();
  const k = String(id);
  cart[k] = clamp(Number(qty||0), 0, 999);
  if(cart[k] <= 0) delete cart[k];
  setCart(cart);
  return cart;
}
export function removeFromCart(id){
  const cart = getCart();
  delete cart[String(id)];
  setCart(cart);
  return cart;
}
export function clearCart(){
  setCart({});
}
