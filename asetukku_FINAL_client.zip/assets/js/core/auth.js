import { storage } from "./storage.js";

const KEY = "asetukku_auth_v1";

export function isAuthed(){
  const s = storage.get(KEY, null);
  return !!(s && s.ok);
}
export function getUser(){
  return storage.get(KEY, null);
}
export function loginAny({email, name}={}){
  storage.set(KEY, {
    ok:true,
    email: email || "asiakas@esimerkki.fi",
    name: name || "Vieraskäyttäjä",
    since: new Date().toISOString()
  });
}
export function logout(){
  storage.del(KEY);
}
