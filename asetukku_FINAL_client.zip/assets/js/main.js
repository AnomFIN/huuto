import { loadProducts, searchProducts } from "./core/products.js";
import { cartCount, getCart, setQty, removeFromCart } from "./core/cart.js";
import { isAuthed, getUser } from "./core/auth.js";
import { money, escapeHtml } from "./core/format.js";
import { toast } from "./ui/toast.js";

async function inject(id, url){
  const host = document.getElementById(id);
  if(!host) return;
  const res = await fetch(url, {cache:"no-store"});
  host.innerHTML = await res.text();
}


function applyTheme(){
  let saved = localStorage.getItem("asetukku_theme");
  if(!saved){ saved = "light"; localStorage.setItem("asetukku_theme", saved); }
  if(saved!=="light" && saved!=="dark"){ saved="light"; localStorage.setItem("asetukku_theme", saved); }
  document.body.classList.toggle("theme-light", saved==="light");
  const btn = document.getElementById("themeBtn");
  if(btn){
    btn.innerHTML = saved==="light" ? '<span class="icon">☀️</span> Vaalea' : '<span class="icon">🌙</span> Tumma';
  }
}
function bindTheme(){
  const btn = document.getElementById("themeBtn");
  if(!btn) return;
  btn.addEventListener("click", ()=>{
    const cur = localStorage.getItem("asetukku_theme") || "light";
    localStorage.setItem("asetukku_theme", cur==="light" ? "dark" : "light");
    applyTheme();
    toast("Teema vaihdettu", "good");
  });
}




function bindMobile(){
  const t = document.getElementById("mobileToggle");
  const m = document.getElementById("mobileMenu");
  if(!t || !m) return;
  t.addEventListener("click", ()=>{
    const open = m.style.display !== "none";
    m.style.display = open ? "none" : "block";
  });
}

function setAccountLabel(){
  const lab = document.getElementById("accountLabel");
  if(!lab) return;
  if(isAuthed()){
    const u = getUser();
    lab.textContent = u?.name?.split(" ")[0] || "Tili";
  }else{
    lab.textContent = "Kirjaudu";
  }
}

function renderCart(products){
  const cart = getCart();
  const body = document.getElementById("cartBody");
  const totalEl = document.getElementById("cartTotal");
  const badge = document.getElementById("cartBadge");
  if(badge) badge.textContent = String(cartCount(cart));

  if(!body || !totalEl) return;

  const ids = Object.keys(cart);
  if(ids.length === 0){
    body.innerHTML = `<div class="notice"><strong>Ostoskori on tyhjä.</strong><div class="small" style="margin-top:6px">Lisää tuotteita listauksesta tai tuotesivulta.</div></div>`;
    totalEl.textContent = money(0);
    return;
  }

  let sum = 0;
  body.innerHTML = ids.map(id=>{
    const p = products.find(x=>String(x.id)===String(id));
    const qty = cart[id];
    if(!p) return "";
    sum += p.price * qty;
    return `
      <div class="line">
        <div style="display:flex;gap:12px;align-items:center;min-width:0">
          <div style="width:54px;height:54px;border-radius:14px;overflow:hidden;border:1px solid rgba(255,255,255,.10);background:rgba(255,255,255,.03)">
            <img src="${p.images?.[0] || "assets/img/ui/placeholder.jpg"}" alt="" style="width:100%;height:100%;object-fit:cover">
          </div>
          <div style="min-width:0">
            <div style="font-weight:1000;font-size:12px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis">${escapeHtml(p.name)}</div>
            <div class="small">${escapeHtml(p.brand||"")} • ${money(p.price)}</div>
          </div>
        </div>
        <div style="display:grid;gap:8px;justify-items:end">
          <div class="qty">
            <button type="button" data-qty="-1" data-id="${p.id}">−</button>
            <span>${qty}</span>
            <button type="button" data-qty="1" data-id="${p.id}">+</button>
          </div>
          <button class="btn small" data-remove="${p.id}" type="button">Poista</button>
        </div>
      </div>
    `;
  }).join("");

  totalEl.textContent = money(sum);

  body.querySelectorAll("button[data-qty]").forEach(btn=>{
    btn.addEventListener("click", ()=>{
      const id = btn.getAttribute("data-id");
      const delta = Number(btn.getAttribute("data-qty"));
      const c = getCart();
      const next = (c[id]||0)+delta;
      setQty(id, next);
      renderCart(products);
      toast("Ostoskori päivitetty", "good");
    });
  });
  body.querySelectorAll("button[data-remove]").forEach(btn=>{
    btn.addEventListener("click", ()=>{
      const id = btn.getAttribute("data-remove");
      removeFromCart(id);
      renderCart(products);
      toast("Poistettu ostoskorista", "warn");
    });
  });
}

function bindCart(products){
  const drawer = document.getElementById("cartDrawer");
  const btn = document.getElementById("cartBtn");
  const close = document.getElementById("cartClose");
  if(!drawer || !btn || !close) return;

  const open = ()=>{
    drawer.classList.add("open");
    renderCart(products);
  };
  const shut = ()=>{
    drawer.classList.remove("open");
  };

  btn.addEventListener("click", open);
  close.addEventListener("click", shut);
  drawer.addEventListener("click", (e)=>{
    if(e.target === drawer) shut();
  });
  document.addEventListener("keydown", (e)=>{
    if(e.key === "Escape") shut();
  });
}

function bindSearch(products){
  const form = document.getElementById("siteSearchForm");
  const input = document.getElementById("siteSearchInput");
  const sug = document.getElementById("siteSuggest");
  if(!form || !input || !sug) return;

  const close = ()=>{sug.classList.remove("open");};
  const open = ()=>{sug.classList.add("open");};

  let t=null;
  input.addEventListener("input", ()=>{
    clearTimeout(t);
    t=setTimeout(()=>{
      const q=input.value.trim();
      const hits = searchProducts(products, q);
      if(!q || hits.length===0){ close(); return; }
      sug.innerHTML = hits.map(p=>`
        <a href="product.html?id=${encodeURIComponent(p.id)}">
          <span>
            <span class="title">${escapeHtml(p.name)}</span><br>
            <span class="hint">${escapeHtml(p.brand||"")} • ${escapeHtml(p.category||"")}</span>
          </span>
          <span class="price">${money(p.price)}</span>
        </a>
      `).join("");
      open();
    }, 120);
  });
  input.addEventListener("focus", ()=>{ if(sug.innerHTML.trim()) open(); });
  document.addEventListener("click",(e)=>{
    if(!form.contains(e.target)) close();
  });

  form.addEventListener("submit",(e)=>{
    e.preventDefault();
    const q = input.value.trim();
    if(!q) return;
    location.href = `search.html?q=${encodeURIComponent(q)}`;
  });
}

async function boot(){
  await inject("siteHeader","partials/header.html");
  await inject("siteFooter","partials/footer.html");

  applyTheme();
  bindTheme();
  bindMobile();
  setAccountLabel();

  const products = await loadProducts();
  bindCart(products);
  bindSearch(products);
  renderCart(products);

  // Page init
  const page = document.body?.dataset?.page;
  if(page){
    try{
      const mod = await import(`./pages/${page}.js`);
      if(mod?.init) await mod.init({products, toast});
    }catch(e){
      // ignore missing pages
      console.warn("Page init failed", page, e);
    }
  }
}

boot();
