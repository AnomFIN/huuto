import { getCart, setQty, removeFromCart, clearCart } from "../core/cart.js";
import { money, escapeHtml } from "../core/format.js";

export async function init({products, toast}){
  const list = document.getElementById("cartList");
  const sumEl = document.getElementById("sumTotal");
  const badge = document.getElementById("cartBadge");

  const render = ()=>{
    const cart = getCart();
    const ids = Object.keys(cart);
    let sum = 0;

    if(ids.length===0){
      list.innerHTML = `<div class="notice"><strong>Kori on tyhjä.</strong><div class="small" style="margin-top:6px"><a href="index.html" style="color:var(--accent);font-weight:1000">Palaa etusivulle</a> ja lisää tuotteita.</div></div>`;
      sumEl.textContent = money(0);
      if(badge) badge.textContent = "0";
      return;
    }

    list.innerHTML = ids.map(id=>{
      const p = products.find(x=>String(x.id)===String(id));
      if(!p) return "";
      const qty = cart[id];
      sum += p.price * qty;
      return `
        <div class="card" style="margin-bottom:12px">
          <div class="pad" style="display:flex;gap:14px;align-items:center;flex-wrap:wrap">
            <div style="width:92px;height:92px;border-radius:18px;overflow:hidden;border:1px solid rgba(255,255,255,.10);background:rgba(255,255,255,.03)">
              <img src="${p.images?.[0]||"assets/img/ui/placeholder.jpg"}" alt="" style="width:100%;height:100%;object-fit:cover">
            </div>
            <div style="flex:1;min-width:220px">
              <div class="small">${escapeHtml(p.brand||"")} • ${escapeHtml(p.category||"")}</div>
              <div style="font-weight:1200;margin-top:6px">${escapeHtml(p.name)}</div>
              <div class="small" style="margin-top:6px">${money(p.price)} / kpl</div>
            </div>

            <div style="display:grid;gap:10px;justify-items:end">
              <div class="qty">
                <button type="button" data-qty="-1" data-id="${p.id}">−</button>
                <span>${qty}</span>
                <button type="button" data-qty="1" data-id="${p.id}">+</button>
              </div>
              <button class="btn small" data-remove="${p.id}" type="button">Poista</button>
              <div class="small">Rivi: <strong>${money(p.price*qty)}</strong></div>
            </div>
          </div>
        </div>
      `;
    }).join("");

    sumEl.textContent = money(sum);
    if(badge) badge.textContent = String(ids.reduce((a,k)=>a+cart[k],0));

    list.querySelectorAll("button[data-qty]").forEach(btn=>{
      btn.addEventListener("click", ()=>{
        const id = btn.getAttribute("data-id");
        const delta = Number(btn.getAttribute("data-qty"));
        const c = getCart();
        setQty(id, (c[id]||0)+delta);
        render();
        toast("Päivitetty", "good");
      });
    });
    list.querySelectorAll("button[data-remove]").forEach(btn=>{
      btn.addEventListener("click", ()=>{
        removeFromCart(btn.getAttribute("data-remove"));
        render();
        toast("Poistettu", "warn");
      });
    });
  };

  document.getElementById("clearCartBtn").addEventListener("click", ()=>{
    clearCart();
    render();
    toast("Ostoskori tyhjennetty", "warn");
  });

  render();
}
