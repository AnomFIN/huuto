import { loadProducts } from "../core/products.js";
import { money, escapeHtml } from "../core/format.js";
import { addToCart } from "../core/cart.js";

async function loadSite(){
  const res = await fetch("data/site.json", {cache:"no-store"});
  return await res.json();
}

function productCard(p){
  const img = p.images?.[0] || "assets/img/ui/placeholder.jpg";
  const tag = p.badge ? `<span class="tag">${escapeHtml(p.badge)}</span>` : "";
  const old = p.old_price ? `<span class="small" style="text-decoration:line-through">${money(p.old_price)}</span>` : "";
  return `
    <article class="card pcard">
      <a href="product.html?id=${encodeURIComponent(p.id)}" aria-label="${escapeHtml(p.name)}">
        <div class="media">
          ${tag}
          <img src="${img}" alt="">
        </div>
      </a>
      <div class="body">
        <div class="small">${escapeHtml(p.brand||"")} • ${escapeHtml(p.subcategory||p.category||"")}</div>
        <div class="name" style="margin-top:6px">${escapeHtml(p.name)}</div>
        <div class="meta">
          <div class="price">${money(p.price)} ${old}</div>
          <div class="small">★ ${Number(p.rating||0).toFixed(1)}</div>
        </div>
        <div class="actions">
          <button class="btn small primary" data-add="${p.id}" type="button">Lisää koriin</button>
          <a class="btn small" href="product.html?id=${encodeURIComponent(p.id)}">Katso</a>
        </div>
      </div>
    </article>
  `;
}

export async function init({products, toast}){
  const site = await loadSite();

  const heroBg = document.getElementById("heroBg");
  const heroTex = document.getElementById("heroTex");
  if(heroBg) heroBg.style.backgroundImage = `url('${site.hero.bg}'), url('assets/img/photos/fallback_hero1.jpg')`;
  if(heroTex) heroTex.style.backgroundImage = `url('${site.hero.tex}'), url('assets/img/photos/fallback_camo1.jpg')`;

  const catGrid = document.getElementById("catGrid");
  if(catGrid){
    catGrid.innerHTML = site.categories.map(c=>`
      <a class="cat" href="category.html?c=${encodeURIComponent(c.name)}">
        <div class="bg" style="background-image:url('${c.img}')"></div>
        <div class="overlay">
          <div>
            <div class="title">${escapeHtml(c.name)}</div>
            <div class="meta">${escapeHtml(c.desc||"")}</div>
          </div>
          <span class="btn small">Selaa →</span>
        </div>
      </a>
    `).join("");
  }

  // Featured: 12 high-rated products, mix of categories
  const pick = products
    .slice()
    .sort((a,b)=>(b.rating||0)-(a.rating||0))
    .slice(0, 24);
  const featured = [];
  const seenCat = new Set();
  for(const p of pick){
    if(featured.length>=12) break;
    if(!seenCat.has(p.category) || featured.length<8){
      featured.push(p);
      seenCat.add(p.category);
    }
  }

  const featuredGrid = document.getElementById("featuredGrid");
  if(featuredGrid){
    featuredGrid.innerHTML = featured.map(productCard).join("");
    featuredGrid.querySelectorAll("button[data-add]").forEach(btn=>{
      btn.addEventListener("click", ()=>{
        const id = btn.getAttribute("data-add");
        addToCart(id, 1);
        toast("Lisätty ostoskoriin", "good");
        // badge updates in main render
        document.getElementById("cartBadge").textContent = String(Object.values(JSON.parse(localStorage.getItem("asetukku_cart_v2")||"{}")).reduce((a,b)=>a+Number(b||0),0));
      });
    });
  }
}
