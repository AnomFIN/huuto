import { brandsFor, filterProducts } from "../core/products.js";
import { money, escapeHtml, qs } from "../core/format.js";
import { addToCart } from "../core/cart.js";

async function loadSite(){
  const res = await fetch("data/site.json", {cache:"no-store"});
  return await res.json();
}

function productCard(p){
  const img = p.images?.[0] || "assets/img/ui/placeholder.jpg";
  const tag = p.badge ? `<span class="tag">${escapeHtml(p.badge)}</span>` : "";
  const old = p.old_price ? `<span class="small" style="text-decoration:line-through">${money(p.old_price)}</span>` : "";
  return `
    <article class="card pcard">
      <a href="product.html?id=${encodeURIComponent(p.id)}">
        <div class="media">
          ${tag}
          <img src="${img}" alt="">
        </div>
      </a>
      <div class="body">
        <div class="small">${escapeHtml(p.brand||"")} • ${escapeHtml(p.subcategory||"")}</div>
        <div class="name" style="margin-top:6px">${escapeHtml(p.name)}</div>
        <div class="meta">
          <div class="price">${money(p.price)} ${old}</div>
          <div class="small">★ ${Number(p.rating||0).toFixed(1)}</div>
        </div>
        <div class="actions">
          <button class="btn small primary" data-add="${p.id}" type="button">Lisää koriin</button>
          <a class="btn small" href="product.html?id=${encodeURIComponent(p.id)}">Katso</a>
        </div>
      </div>
    </article>
  `;
}

function readChecks(root){
  return Array.from(root.querySelectorAll("input[type=checkbox]:checked")).map(x=>x.value);
}

export async function init({products, toast}){
  const site = await loadSite();

  const cat = qs("c") || "Aseet";
  const badge = qs("badge"); // optional deep link
  const q0 = qs("q") || "";

  // Header breadcrumb
  const bc = `
    <div class="breadcrumb">
      <a href="index.html">Etusivu</a><span class="sep">/</span>
      <a href="category.html?c=${encodeURIComponent(cat)}">${escapeHtml(cat)}</a>
      ${badge ? `<span class="sep">/</span><span>${escapeHtml(badge)}</span>` : ""}
    </div>
  `;
  document.getElementById("catHeader").innerHTML = bc;

  const meta = site.categories.find(x=>x.name===cat);
  document.getElementById("catTitle").textContent = cat;
  document.getElementById("catDesc").textContent = meta?.desc || "Valitse suodattimet ja selaa tuotteita.";


  const sub = qs("s") || "";
  const subs = Array.from(new Set(products.filter(p=>p.category===cat).map(p=>p.subcategory))).sort((a,b)=>a.localeCompare(b,"fi"));
  const subChips = document.getElementById("subChips");
  if(subChips){
    subChips.innerHTML = [`<button class="chip" data-sub="" type="button">Kaikki</button>`]
      .concat(subs.map(s=>`<button class="chip" data-sub="${escapeHtml(s)}" type="button">${escapeHtml(s)}</button>`))
      .join("");
    subChips.querySelectorAll("button[data-sub]").forEach(btn=>{
      btn.addEventListener("click", ()=>{
        const v = btn.dataset.sub || "";
        const u = new URL(location.href);
        if(v) u.searchParams.set("s", v); else u.searchParams.delete("s");
        location.href = u.toString();
      });
    });
    subChips.querySelectorAll("button[data-sub]").forEach(btn=>{
      btn.style.borderColor = (btn.dataset.sub===sub) ? "rgba(217,194,102,.30)" : "rgba(255,255,255,.12)";
    });
  }


  // Brands
  const brands = brandsFor(products, cat).slice(0, 16);
  const brandChecks = document.getElementById("brandChecks");
  if(brandChecks){
    brandChecks.innerHTML = brands.map(b=>`<label class="chk"><input type="checkbox" value="${escapeHtml(b)}"> ${escapeHtml(b)}</label>`).join("");
  }

  // Prefill
  const fQ = document.getElementById("fQ");
  const fMin = document.getElementById("fMin");
  const fMax = document.getElementById("fMax");
  const fSort = document.getElementById("fSort");
  if(fQ) fQ.value = q0;

  if(badge){
    const bcRoot = document.getElementById("badgeChecks");
    const found = Array.from(bcRoot.querySelectorAll("input[type=checkbox]")).find(x=>x.value===badge);
    if(found) found.checked = true;
  }

  function apply(){
    const brandsSel = brandChecks ? readChecks(brandChecks) : [];
    const badgesSel = readChecks(document.getElementById("badgeChecks"));
    const minPrice = fMin.value ? Number(fMin.value) : undefined;
    const maxPrice = fMax.value ? Number(fMax.value) : undefined;

    const out = filterProducts(products, {
      category: cat,
      subcategory: sub || undefined,
      q: fQ.value.trim(),
      brands: brandsSel,
      badges: badgesSel,
      minPrice,
      maxPrice,
      sort: fSort.value
    });

    document.getElementById("resultCount").textContent = String(out.length);

    const grid = document.getElementById("productGrid");
    grid.innerHTML = out.slice(0, 80).map(productCard).join("") + (out.length>80 ? `<div class="notice"><strong>Huom:</strong><div class="small" style="margin-top:6px">Näytetään 80 / ${out.length} tuotetta. Sivutus lisätään käyttöönotossa.</div></div>` : "");

    grid.querySelectorAll("button[data-add]").forEach(btn=>{
      btn.addEventListener("click", ()=>{
        const id = btn.getAttribute("data-add");
        addToCart(id, 1);
        toast("Lisätty ostoskoriin", "good");
        document.getElementById("cartBadge").textContent = String(Object.values(JSON.parse(localStorage.getItem("asetukku_cart_v2")||"{}")).reduce((a,b)=>a+Number(b||0),0));
      });
    });
  }

  document.getElementById("applyFilters").addEventListener("click", apply);
  document.getElementById("clearFilters").addEventListener("click", ()=>{
    fQ.value="";
    fMin.value="";
    fMax.value="";
    if(brandChecks) brandChecks.querySelectorAll("input").forEach(i=>i.checked=false);
    document.getElementById("badgeChecks").querySelectorAll("input").forEach(i=>i.checked=false);
    fSort.value="popular";
    apply();
  });

  apply();
}
