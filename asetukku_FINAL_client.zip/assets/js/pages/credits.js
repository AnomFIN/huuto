import { escapeHtml } from "../core/format.js";

export async function init(){
  const res = await fetch("data/credits.json", {cache:"no-store"});
  const items = await res.json();
  const host = document.getElementById("creditsList");
  host.innerHTML = items.map(x=>`
    <div class="card">
      <div class="pad">
        <strong>${escapeHtml(x.title)}</strong>
        <div class="small" style="margin-top:6px">Lisenssi: ${escapeHtml(x.license)}</div>
        <div class="small" style="margin-top:6px">Lähde: <a href="${escapeHtml(x.source)}" target="_blank" rel="noopener" style="color:var(--accent);font-weight:1000">Wikimedia Commons</a></div>
      </div>
    </div>
  `).join("");
}
