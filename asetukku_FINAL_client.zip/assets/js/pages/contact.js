import { escapeHtml } from "../core/format.js";

const KEY = "asetukku_contact_v1";
const getAll = ()=>{ try{return JSON.parse(localStorage.getItem(KEY)||"[]");}catch(e){return [];} };
const setAll = (x)=>localStorage.setItem(KEY, JSON.stringify(x));

export async function init({toast}){
  const res = document.getElementById("msgResult");
  document.getElementById("sendMsg").addEventListener("click", ()=>{
    const payload = {
      at: new Date().toISOString(),
      name: document.getElementById("cName2").value.trim(),
      email: document.getElementById("cEmail2").value.trim(),
      topic: document.getElementById("cTopic").value,
      msg: document.getElementById("cMsg").value.trim(),
      ref: `MSG-${Date.now().toString(36).toUpperCase()}`
    };
    if(!payload.name || !payload.email || !payload.msg){
      toast("Täytä nimi, sähköposti ja viesti", "warn");
      return;
    }
    const all = getAll();
    all.unshift(payload);
    setAll(all.slice(0, 50));
    res.classList.remove("hidden");
    res.innerHTML = `
      <div class="notice good">
        <strong>Kiitos!</strong>
        <div class="small" style="margin-top:6px">Viite: <strong>${escapeHtml(payload.ref)}</strong></div>
        <div class="small" style="margin-top:6px">Tallennettu selaimeen.</div>
      </div>
    `;
    toast("Viesti lähetetty", "good");
  });
}
