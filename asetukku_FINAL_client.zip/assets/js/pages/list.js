import { escapeHtml } from "../core/format.js";

const KEY = "asetukku_listings_v1";
const getAll = ()=>{ try{return JSON.parse(localStorage.getItem(KEY)||"[]");}catch(e){return [];} };
const setAll = (x)=>localStorage.setItem(KEY, JSON.stringify(x));

function v(id){ return document.getElementById(id).value.trim(); }

export async function init({toast}){
  const res = document.getElementById("listResult");
  document.getElementById("listSend").addEventListener("click", ()=>{
    const payload = {
      at: new Date().toISOString(),
      cat: v("lCat"),
      brand: v("lBrand"),
      model: v("lModel"),
      price: v("lPrice"),
      desc: v("lDesc"),
      name: v("lName"),
      email: v("lEmail"),
      ref: `LS-${Date.now().toString(36).toUpperCase()}`
    };

    if(!payload.brand || !payload.model || !payload.name || !payload.email){
      toast("Täytä vähintään merkki, malli, nimi ja sähköposti", "warn");
      return;
    }

    const all = getAll();
    all.unshift(payload);
    setAll(all.slice(0, 50));

    res.classList.remove("hidden");
    res.innerHTML = `
      <div class="notice good">
        <strong>Ilmoitus vastaanotettu!</strong>
        <div class="small" style="margin-top:6px">Viite: <strong>${escapeHtml(payload.ref)}</strong></div>
        <div class="small" style="margin-top:6px">Tallennettu selaimeen. Näet sen “Oma tili” -sivulla.</div>
      </div>
    `;
    toast("Ilmoitus jätetty", "good");
  });
}
