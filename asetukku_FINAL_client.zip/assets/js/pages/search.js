import { filterProducts } from "../core/products.js";
import { money, escapeHtml, qs } from "../core/format.js";
import { addToCart } from "../core/cart.js";

function card(p){
  const img = p.images?.[0] || "assets/img/ui/placeholder.jpg";
  const tag = p.badge ? `<span class="tag">${escapeHtml(p.badge)}</span>` : "";
  return `
    <article class="card pcard">
      <a href="product.html?id=${encodeURIComponent(p.id)}">
        <div class="media">${tag}<img src="${img}" alt=""></div>
      </a>
      <div class="body">
        <div class="small">${escapeHtml(p.category||"")} • ${escapeHtml(p.brand||"")}</div>
        <div class="name" style="margin-top:6px">${escapeHtml(p.name)}</div>
        <div class="meta">
          <div class="price">${money(p.price)}</div>
          <div class="small">★ ${Number(p.rating||0).toFixed(1)}</div>
        </div>
        <div class="actions">
          <button class="btn small primary" data-add="${p.id}" type="button">Lisää koriin</button>
          <a class="btn small" href="product.html?id=${encodeURIComponent(p.id)}">Katso</a>
        </div>
      </div>
    </article>
  `;
}

export async function init({products, toast}){
  const q = (qs("q")||"").trim();
  document.getElementById("qLabel").textContent = q ? `"${q}"` : "(ei hakusanaa)";

  const cats = Array.from(new Set(products.map(p=>p.category))).sort((a,b)=>a.localeCompare(b,"fi"));
  const chips = document.getElementById("catChips");
  chips.innerHTML = [`<span class="pill"><strong>${products.length}</strong> tuotetta kannassa</span>`]
    .concat(cats.map(c=>`<button class="chip" data-cat="${escapeHtml(c)}" type="button">${escapeHtml(c)}</button>`))
    .join("");

  let activeCat = null;

  const render = ()=>{
    const out = filterProducts(products, {q, category: activeCat || undefined, sort: document.getElementById("sSort").value});
    const grid = document.getElementById("searchGrid");
    grid.innerHTML = out.slice(0, 60).map(card).join("") + (out.length===0 ? `<div class="notice"><strong>Ei tuloksia.</strong><div class="small" style="margin-top:6px">Kokeile eri hakusanaa tai katso kampanjat.</div></div>` : "");
    grid.querySelectorAll("button[data-add]").forEach(btn=>{
      btn.addEventListener("click", ()=>{
        addToCart(btn.getAttribute("data-add"), 1);
        toast("Lisätty ostoskoriin", "good");
        document.getElementById("cartBadge").textContent = String(Object.values(JSON.parse(localStorage.getItem("asetukku_cart_v2")||"{}")).reduce((a,b)=>a+Number(b||0),0));
      });
    });
    chips.querySelectorAll("button.chip").forEach(b=>b.style.borderColor = (b.dataset.cat===activeCat) ? "rgba(217,194,102,.30)" : "rgba(255,255,255,.12)");
  };

  chips.addEventListener("click",(e)=>{
    const btn = e.target.closest("button[data-cat]");
    if(!btn) return;
    const c = btn.dataset.cat;
    activeCat = activeCat === c ? null : c;
    render();
  });
  document.getElementById("sSort").addEventListener("change", render);

  render();
}
