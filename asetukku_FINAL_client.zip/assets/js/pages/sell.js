import { escapeHtml } from "../core/format.js";

const KEY = "asetukku_sell_requests_v1";
const getAll = ()=>{ try{return JSON.parse(localStorage.getItem(KEY)||"[]");}catch(e){return [];} };
const setAll = (x)=>localStorage.setItem(KEY, JSON.stringify(x));

function v(id){ return document.getElementById(id).value.trim(); }

export async function init({toast}){
  const res = document.getElementById("sellResult");
  document.getElementById("sellSend").addEventListener("click", ()=>{
    const payload = {
      at: new Date().toISOString(),
      type: v("sType"),
      brand: v("sBrand"),
      model: v("sModel"),
      cal: v("sCal"),
      cond: v("sCond"),
      ask: v("sAsk"),
      notes: v("sNotes"),
      name: v("sName"),
      email: v("sEmail"),
      ref: `SR-${Date.now().toString(36).toUpperCase()}`
    };

    if(!payload.brand || !payload.model || !payload.name || !payload.email){
      toast("Täytä vähintään merkki, malli, nimi ja sähköposti", "warn");
      return;
    }

    const all = getAll();
    all.unshift(payload);
    setAll(all.slice(0, 50));

    res.classList.remove("hidden");
    res.innerHTML = `
      <div class="notice good">
        <strong>Vastaanotettu!</strong>
        <div class="small" style="margin-top:6px">Viitenumero: <strong>${escapeHtml(payload.ref)}</strong></div>
        <div class="small" style="margin-top:6px">Tallennettu selaimeen. Näet sen myös “Oma tili” -sivulla.</div>
      </div>
    `;
    toast("Arviopyyntö lähetetty", "good");
  });
}
