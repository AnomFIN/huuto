import { getProductById } from "../core/products.js";
import { money, escapeHtml, qs, clamp } from "../core/format.js";
import { addToCart } from "../core/cart.js";

function setTab(tab){
  document.querySelectorAll("#tabbar button").forEach(b=>b.classList.toggle("active", b.dataset.tab===tab));
  document.querySelectorAll(".tabcontent").forEach(el=>el.classList.toggle("active", el.id===`tab-${tab}`));
}

function productCard(p){
  const img = p.images?.[0] || "assets/img/ui/placeholder.jpg";
  const tag = p.badge ? `<span class="tag">${escapeHtml(p.badge)}</span>` : "";
  return `
    <article class="card pcard">
      <a href="product.html?id=${encodeURIComponent(p.id)}">
        <div class="media">${tag}<img src="${img}" alt=""></div>
      </a>
      <div class="body">
        <div class="small">${escapeHtml(p.brand||"")} • ${escapeHtml(p.subcategory||p.category||"")}</div>
        <div class="name" style="margin-top:6px">${escapeHtml(p.name)}</div>
        <div class="meta">
          <div class="price">${money(p.price)}</div>
          <div class="small">★ ${Number(p.rating||0).toFixed(1)}</div>
        </div>
      </div>
    </article>
  `;
}

export async function init({products, toast}){
  const id = qs("id");
  const p = getProductById(products, id);
  if(!p){
    location.href = "404.html";
    return;
  }

  document.getElementById("pBreadcrumb").innerHTML = `
    <a href="index.html">Etusivu</a><span class="sep">/</span>
    <a href="category.html?c=${encodeURIComponent(p.category)}">${escapeHtml(p.category)}</a><span class="sep">/</span>
    <span>${escapeHtml(p.name)}</span>
  `;

  // Header details
  document.title = `Asetukku — ${p.name}`;
  document.getElementById("pBadge").textContent = p.badge || "Tuote";
  document.getElementById("pMeta").textContent = `${p.brand||""}`.trim();
  document.getElementById("pName").textContent = p.name;
  document.getElementById("pSub").textContent = `${p.subcategory||""} • ★ ${Number(p.rating||0).toFixed(1)} (${p.reviews||0} arviota)`;
  document.getElementById("pPrice").textContent = money(p.price);
  document.getElementById("pOld").textContent = p.old_price ? money(p.old_price) : "";
  document.getElementById("pStock").textContent = p.stock > 0 ? `Saatavilla (${p.stock})` : "Tilaustuote";
  document.getElementById("pSku").textContent = p.sku || `ASK-${p.id}`;

  // Gallery
  const imgs = (p.images && p.images.length) ? p.images : ["assets/img/ui/placeholder.jpg"];
  const mainImg = document.getElementById("mainImg");
  const thumbs = document.getElementById("thumbs");
  mainImg.src = imgs[0];
  thumbs.innerHTML = imgs.map((src,i)=>`<img src="${src}" alt="" data-i="${i}" class="${i===0?"active":""}">`).join("");
  thumbs.querySelectorAll("img").forEach(img=>{
    img.addEventListener("click", ()=>{
      const i = Number(img.dataset.i);
      mainImg.src = imgs[i];
      thumbs.querySelectorAll("img").forEach(x=>x.classList.toggle("active", x===img));
    });
  });

  // Tabs
  document.getElementById("tab-desc").innerHTML = `
    <p class="p">${escapeHtml(p.description || "Laadukas tuote vaativaan käyttöön. Rehelliset tiedot ja selkeä toimituspolku.")}</p>
    <div class="hr"></div>
    <div class="notice">
      <strong>Huomio</strong>
      <div class="small" style="margin-top:6px">Jos tuote on luvanvarainen, toimitus ja luovutus tapahtuu lain ja lupien mukaisesti. </div>
    </div>
  `;
  const specs = p.specs || {};
  document.getElementById("tab-specs").innerHTML = `
    <div class="grid cols-2">
      ${Object.entries(specs).map(([k,v])=>`
        <div class="card"><div class="pad">
          <div class="small">${escapeHtml(k)}</div>
          <div style="font-weight:1100;margin-top:6px">${escapeHtml(v)}</div>
        </div></div>
      `).join("")}
    </div>
  `;
  document.getElementById("tab-delivery").innerHTML = `
    <div class="grid cols-2">
      <div class="card"><div class="pad">
        <div style="font-weight:1100">Toimitus</div>
        <p class="p" style="margin-top:6px">Nouto / Posti / Matkahuolto. Seuranta ja ilmoitukset mukana.</p>
      </div></div>
      <div class="card"><div class="pad">
        <div style="font-weight:1100">Palautus</div>
        <p class="p" style="margin-top:6px">Palautus 14 vrk ei-luvanvaraisille tuotteille. Luvanvaraiset erikseen.</p>
      </div></div>
    </div>
  `;
  document.getElementById("tab-reviews").innerHTML = `
    <div class="notice">
      <strong>Arviot</strong>
      <div class="small" style="margin-top:6px">Voit toteuttaa oikeat arviot myöhemmin backendillä. Nyt luodaan esimerkkikommentit tuotteesta.</div>
    </div>
    <div class="hr"></div>
    <div class="grid">
      ${Array.from({length:3}).map((_,i)=>`
        <div class="card"><div class="pad">
          <div style="display:flex;justify-content:space-between;gap:12px;flex-wrap:wrap">
            <strong>Asiakas #${(Number(p.id)*7 + i*13)%97 + 1}</strong>
            <span class="small">★ ${(Math.min(5, Math.max(3.5, (p.rating||4) + (i-1)*0.2))).toFixed(1)}</span>
          </div>
          <p class="p" style="margin-top:6px">Hyvä laatu ja nopea toimitus. Pakkaus siisti. </p>
        </div></div>
      `).join("")}
    </div>
  `;

  document.getElementById("tabbar").addEventListener("click",(e)=>{
    const btn = e.target.closest("button[data-tab]");
    if(!btn) return;
    setTab(btn.dataset.tab);
  });

  // Quantity + add
  let qty = 1;
  const qv = document.getElementById("qtyVal");
  const upd = ()=>{ qv.textContent = String(qty); };
  document.getElementById("qtyMinus").addEventListener("click", ()=>{ qty = clamp(qty-1,1,99); upd(); });
  document.getElementById("qtyPlus").addEventListener("click", ()=>{ qty = clamp(qty+1,1,99); upd(); });
  document.getElementById("addBtn").addEventListener("click", ()=>{
    addToCart(p.id, qty);
    toast("Lisätty ostoskoriin", "good");
    document.getElementById("cartBadge").textContent = String(Object.values(JSON.parse(localStorage.getItem("asetukku_cart_v2")||"{}")).reduce((a,b)=>a+Number(b||0),0));
  });

  // Related
  const related = products.filter(x=>x.category===p.category && x.id!==p.id).slice().sort((a,b)=>(b.rating||0)-(a.rating||0)).slice(0,8);
  const grid = document.getElementById("relatedGrid");
  grid.innerHTML = related.map(productCard).join("");
}
