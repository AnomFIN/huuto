import { getCart, clearCart } from "../core/cart.js";
import { isAuthed, getUser, loginAny } from "../core/auth.js";
import { money, escapeHtml, clamp } from "../core/format.js";
import { toast } from "../ui/toast.js";

const ORDER_KEY = "asetukku_orders_v1";

function getOrders(){
  try{ return JSON.parse(localStorage.getItem(ORDER_KEY)||"[]"); }catch(e){ return []; }
}
function setOrders(o){ localStorage.setItem(ORDER_KEY, JSON.stringify(o)); }

function shippingCost(method){
  if(method==="Nouto") return 0;
  if(method==="Matkahuolto") return 7.90;
  if(method==="Posti") return 9.90;
  if(method==="Express") return 14.90;
  return 0;
}

function selRadio(name){
  const el = document.querySelector(`input[name="${name}"]:checked`);
  return el ? el.value : null;
}

export async function init({products}){
  // Ensure we have a "user" for order view
  if(!isAuthed()){
    // silent auto-login to keep checkout smooth
    loginAny({email:"asiakas@esimerkki.fi", name:"Vieraskäyttäjä"});
    document.getElementById("accountLabel").textContent = "Tili";
  }

  const steps = [1,2,3,4];
  let step = 1;

  const stepLabel = document.getElementById("stepLabel");
  const stepTitle = document.getElementById("stepTitle");
  const prevBtn = document.getElementById("prevBtn");
  const nextBtn = document.getElementById("nextBtn");

  function show(){
    steps.forEach(n=>{
      document.getElementById(`step${n}`).classList.toggle("hidden", n!==step);
    });
    stepLabel.textContent = String(step);
    stepTitle.textContent = step===1 ? "Osoitetiedot" : step===2 ? "Toimitus" : step===3 ? "Maksu" : "Valmis";
    prevBtn.disabled = step===1 || step===4;
    prevBtn.style.opacity = prevBtn.disabled ? .6 : 1;
    nextBtn.textContent = step===3 ? "Vahvista tilaus →" : step===4 ? "Valmis" : "Jatka →";
    nextBtn.disabled = step===4;
    nextBtn.style.opacity = nextBtn.disabled ? .6 : 1;
    renderSummary();
  }

  function renderSummary(){
    const cart = getCart();
    const ids = Object.keys(cart);
    const box = document.getElementById("checkoutSummary");
    if(ids.length===0){
      box.innerHTML = `<div class="notice"><strong>Kori on tyhjä.</strong><div class="small" style="margin-top:6px"><a href="index.html" style="color:var(--accent);font-weight:1000">Palaa etusivulle</a></div></div>`;
      return;
    }

    let sum=0;
    const lines = ids.map(id=>{
      const p = products.find(x=>String(x.id)===String(id));
      if(!p) return "";
      const qty = cart[id];
      sum += p.price*qty;
      return `<div class="line">
        <div style="min-width:0">
          <div style="font-weight:1000;font-size:12px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis">${escapeHtml(p.name)}</div>
          <div class="small">${qty} × ${money(p.price)}</div>
        </div>
        <div style="font-weight:1100">${money(p.price*qty)}</div>
      </div>`;
    }).join("");

    const ship = selRadio("ship") || "Nouto";
    const shipCost = shippingCost(ship);
    const total = sum + shipCost;

    box.innerHTML = `
      <div class="card">
        <div class="pad">
          ${lines}
          <div class="hr"></div>
          <div class="total"><span>Välisummaa</span><span>${money(sum)}</span></div>
          <div class="total"><span>Toimitus (${escapeHtml(ship)})</span><span>${money(shipCost)}</span></div>
          <div class="hr"></div>
          <div class="total" style="font-size:16px"><span>Yhteensä</span><span>${money(total)}</span></div>
        </div>
      </div>
    `;
  }

  function validateStep1(){
    const name = document.getElementById("cName").value.trim();
    const email = document.getElementById("cEmail").value.trim();
    const addr = document.getElementById("cAddr").value.trim();
    const zip = document.getElementById("cZip").value.trim();
    const city = document.getElementById("cCity").value.trim();
    if(!name || !email || !addr || !zip || !city){
      toast("Täytä pakolliset tiedot", "warn");
      return false;
    }
    return true;
  }

  function placeOrder(){
    const cart = getCart();
    const ids = Object.keys(cart);
    if(ids.length===0){
      toast("Ostoskori on tyhjä", "warn");
      return;
    }

    const ship = selRadio("ship") || "Nouto";
    const pay = selRadio("pay") || "Kortti";
    const shipCost = shippingCost(ship);

    let sum=0;
    const items = ids.map(id=>{
      const p = products.find(x=>String(x.id)===String(id));
      const qty = cart[id];
      sum += (p?.price||0)*qty;
      return {id, qty, name:p?.name, price:p?.price};
    });

    const orderNo = `AK-${Date.now().toString(36).toUpperCase()}-${Math.floor(Math.random()*900+100)}`;
    const u = getUser() || {};
    const order = {
      orderNo,
      at: new Date().toISOString(),
      user: {name: document.getElementById("cName").value.trim() || u.name, email: document.getElementById("cEmail").value.trim() || u.email},
      address: {
        addr: document.getElementById("cAddr").value.trim(),
        zip: document.getElementById("cZip").value.trim(),
        city: document.getElementById("cCity").value.trim(),
        phone: document.getElementById("cPhone").value.trim()
      },
      ship, pay,
      sum, shipCost, total: sum+shipCost,
      items
    };

    const orders = getOrders();
    orders.unshift(order);
    setOrders(orders.slice(0, 20));

    clearCart();
    document.getElementById("orderNo").textContent = orderNo;
    document.getElementById("cartBadge").textContent = "0";
    toast("Tilaus luotu", "good");
  }

  prevBtn.addEventListener("click", ()=>{
    step = clamp(step-1,1,4);
    show();
  });

  nextBtn.addEventListener("click", ()=>{
    if(step===1){
      if(!validateStep1()) return;
      step=2; show(); return;
    }
    if(step===2){
      step=3; show(); return;
    }
    if(step===3){
      placeOrder();
      step=4; show(); return;
    }
  });

  show();
}
