import { isAuthed, getUser, logout, loginAny } from "../core/auth.js";
import { money, escapeHtml } from "../core/format.js";

const ORDERS_KEY = "asetukku_orders_v1";
const SELL_KEY = "asetukku_sell_requests_v1";
const LIST_KEY = "asetukku_listings_v1";

const getArr = (k)=>{ try{return JSON.parse(localStorage.getItem(k)||"[]");}catch(e){return [];} };

export async function init({toast}){
  if(!isAuthed()){
    // One-click login for esittelyversio
    loginAny({email:"asiakas@esimerkki.fi", name:"Vieraskäyttäjä"});
  }
  const u = getUser();
  document.getElementById("accHello").textContent = `Hei ${u?.name || "käyttäjä"}!`;

  document.getElementById("logoutBtn").addEventListener("click", ()=>{
    logout();
    toast("Uloskirjautuminen", "warn");
    location.href = "login.html";
  });

  // Orders
  const orders = getArr(ORDERS_KEY);
  const box = document.getElementById("ordersBox");
  if(orders.length===0){
    box.innerHTML = `<div class="notice"><strong>Ei tilauksia vielä.</strong><div class="small" style="margin-top:6px">Tee tilaus kassassa, niin se ilmestyy tänne.</div></div>`;
  }else{
    box.innerHTML = orders.slice(0,5).map(o=>`
      <div class="card" style="margin-bottom:10px">
        <div class="pad">
          <div style="display:flex;justify-content:space-between;gap:12px;flex-wrap:wrap">
            <strong>${escapeHtml(o.orderNo)}</strong>
            <span class="small">${new Date(o.at).toLocaleString("fi-FI")}</span>
          </div>
          <div class="small" style="margin-top:6px">Toimitus: ${escapeHtml(o.ship)} • Maksu: ${escapeHtml(o.pay)}</div>
          <div style="margin-top:6px;font-weight:1200">${money(o.total)}</div>
        </div>
      </div>
    `).join("");
  }

  // Forms
  const sell = getArr(SELL_KEY);
  const list = getArr(LIST_KEY);
  const formsBox = document.getElementById("formsBox");
  const parts = [];
  parts.push(`<div class="notice"><strong>Myy meille</strong><div class="small" style="margin-top:6px">${sell.length} kpl</div><div style="margin-top:10px"><a class="btn small" href="sell.html">Uusi arviopyyntö</a></div></div>`);
  parts.push(`<div class="notice" style="margin-top:12px"><strong>Myynti-ilmoitukset</strong><div class="small" style="margin-top:6px">${list.length} kpl</div><div style="margin-top:10px"><a class="btn small" href="list.html">Uusi ilmoitus</a></div></div>`);

  const last = [...sell.slice(0,2).map(x=>({type:"Arviopyyntö", ref:x.ref, at:x.at, title:`${x.brand} ${x.model}`})),
                ...list.slice(0,2).map(x=>({type:"Ilmoitus", ref:x.ref, at:x.at, title:`${x.brand} ${x.model}`}))]
              .sort((a,b)=>String(b.at).localeCompare(String(a.at))).slice(0,4);

  if(last.length){
    parts.push(`<div class="hr"></div><div class="small">Viimeisimmät:</div>`);
    parts.push(last.map(x=>`
      <div class="card" style="margin-top:10px">
        <div class="pad">
          <div style="display:flex;justify-content:space-between;gap:12px;flex-wrap:wrap">
            <strong>${escapeHtml(x.type)}</strong><span class="small">${escapeHtml(x.ref)}</span>
          </div>
          <div class="small" style="margin-top:6px">${escapeHtml(x.title)}</div>
          <div class="small" style="margin-top:6px">${new Date(x.at).toLocaleString("fi-FI")}</div>
        </div>
      </div>
    `).join(""));
  }

  formsBox.innerHTML = parts.join("");
}
