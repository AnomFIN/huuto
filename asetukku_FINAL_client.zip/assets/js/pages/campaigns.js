import { money, escapeHtml } from "../core/format.js";
import { addToCart } from "../core/cart.js";

function card(p){
  const img = p.images?.[0] || "assets/img/ui/placeholder.jpg";
  const tag = p.badge ? `<span class="tag">${escapeHtml(p.badge)}</span>` : "";
  const old = p.old_price ? `<span class="small" style="text-decoration:line-through;margin-left:8px">${money(p.old_price)}</span>` : "";
  return `
    <article class="card pcard">
      <a href="product.html?id=${encodeURIComponent(p.id)}">
        <div class="media">${tag}<img src="${img}" alt=""></div>
      </a>
      <div class="body">
        <div class="small">${escapeHtml(p.brand||"")} • ${escapeHtml(p.category||"")}</div>
        <div class="name" style="margin-top:6px">${escapeHtml(p.name)}</div>
        <div class="meta">
          <div class="price">${money(p.price)}${old}</div>
          <div class="small">★ ${Number(p.rating||0).toFixed(1)}</div>
        </div>
        <div class="actions">
          <button class="btn small primary" data-add="${p.id}" type="button">Lisää koriin</button>
          <a class="btn small" href="product.html?id=${encodeURIComponent(p.id)}">Katso</a>
        </div>
      </div>
    </article>
  `;
}

function bindAdds(root, toast){
  root.querySelectorAll("button[data-add]").forEach(btn=>{
    btn.addEventListener("click", ()=>{
      addToCart(btn.getAttribute("data-add"), 1);
      toast("Lisätty ostoskoriin", "good");
      document.getElementById("cartBadge").textContent = String(Object.values(JSON.parse(localStorage.getItem("asetukku_cart_v2")||"{}")).reduce((a,b)=>a+Number(b||0),0));
    });
  });
}

export async function init({products, toast}){
  const sales = products.filter(p=>p.badge==="Tarjous" || p.old_price).slice(0,12);
  const news = products.filter(p=>p.badge==="Uutuus").slice(0,12);
  const used = products.filter(p=>p.badge==="Käytetty").slice(0,12);

  const saleGrid = document.getElementById("saleGrid");
  const newGrid = document.getElementById("newGrid");
  const usedGrid = document.getElementById("usedGrid");

  saleGrid.innerHTML = sales.map(card).join("");
  newGrid.innerHTML = news.map(card).join("");
  usedGrid.innerHTML = used.map(card).join("");

  bindAdds(saleGrid, toast);
  bindAdds(newGrid, toast);
  bindAdds(usedGrid, toast);
}
