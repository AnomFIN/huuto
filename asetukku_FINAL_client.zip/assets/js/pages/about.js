export async function init(){/* static */}
