import { loginAny } from "../core/auth.js";

export async function init({toast}){
  document.getElementById("loginBtn").addEventListener("click", ()=>{
    const email = document.getElementById("lEmail").value.trim() || "asiakas@esimerkki.fi";
    const name = email.split("@")[0].replaceAll("."," ").replaceAll("_"," ");
    loginAny({email, name: name ? name[0].toUpperCase()+name.slice(1) : "Vieraskäyttäjä"});
    toast("Kirjautuminen onnistui", "good");
    location.href = "account.html";
  });
}
