let root = null;
export function toast(msg, type="info"){
  if(!root){
    root = document.createElement("div");
    root.style.position="fixed";
    root.style.right="16px";
    root.style.bottom="16px";
    root.style.zIndex="9999";
    root.style.display="grid";
    root.style.gap="10px";
    document.body.appendChild(root);
  }
  const el = document.createElement("div");
  el.className = "card";
  el.style.padding="12px 14px";
  el.style.maxWidth="340px";
  el.style.background="rgba(11,15,12,.92)";
  el.style.borderColor = type==="good" ? "rgba(111,123,59,.35)" : type==="warn" ? "rgba(217,194,102,.30)" : "rgba(255,255,255,.10)";
  el.innerHTML = `<div style="font-weight:1000">${msg}</div><div class="small" style="margin-top:6px">Klikkaa sulkeaksesi</div>`;
  el.addEventListener("click", ()=> el.remove());
  root.appendChild(el);
  setTimeout(()=>{ try{ el.remove(); }catch(e){} }, 3800);
}
