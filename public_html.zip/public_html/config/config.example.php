<?php
/**
 * Configuration Example
 * This file is created by setup.php during installation
 */

return [
    'db' => [
        'host' => 'localhost',
        'name' => 'dajnpsku_jussi',
        'user' => 'dajnpsku_user',
        'pass' => 'MitaVittua=D',
    ],
    'site' => [
        'name' => 'Huuto247',
        'url' => 'https://www.huuto247.fi',
    ]
];
