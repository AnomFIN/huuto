<?php
return array (
  'openai_api_key' => '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',
  'ai_enabled' => true,
  'updated_at' => '2026-02-20 12:26:28',
);
