<?php
// Database configuration
return [
    'host' => getenv('DB_HOST') ?: 'localhost',
    'dbname' => getenv('DB_NAME') ?: 'dajnpsku_jussi',
    'username' => getenv('DB_USER') ?: 'dajnpsku_user',
    'password' => getenv('DB_PASS') ?: 'MitaVittua=D',
    'charset' => 'utf8mb4'
];

