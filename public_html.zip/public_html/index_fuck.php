<?php
http_response_code(503);
?>
<!DOCTYPE html>
<html lang="fi">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Huuto247 – Palvelu poistettu käytöstä</title>
<style>
    body {
        margin: 0;
        font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Arial, sans-serif;
        background: linear-gradient(135deg, #0f172a, #1e293b);
        color: #f1f5f9;
        display: flex;
        align-items: center;
        justify-content: center;
        height: 100vh;
        text-align: center;
    }
    .container {
        max-width: 600px;
        padding: 40px;
    }
    .logo {
        max-width: 180px;
        margin-bottom: 30px;
    }
    h1 {
        font-size: 30px;
        margin-bottom: 20px;
        font-weight: 600;
    }
    p {
        font-size: 18px;
        line-height: 1.6;
        color: #cbd5e1;
    }
    .thanks {
        margin-top: 30px;
        font-size: 20px;
        color: #ffffff;
        font-weight: 500;
    }
    .footer {
        margin-top: 60px;
        font-size: 14px;
        color: #64748b;
    }
</style>
</head>
<body>
    <div class="container">
        <img src="assets/logo.png" alt="Huuto247 Logo" class="logo">

        <h1>Huuto247 on poistettu käytöstä</h1>

        <p>
            Palvelu on lopetettu eikä uusia huutokauppoja tai käyttäjätilejä ole enää saatavilla.
        </p>

        <p class="thanks">
            Kiitos kaikille asiakkaille ja yhteistyökumppaneille kuluneista vuosista.
        </p>

        <div class="footer">
            © <?php echo date("Y"); ?> Huuto247 – Suomalainen Huutokauppa
        </div>
    </div>
</body>
</html>